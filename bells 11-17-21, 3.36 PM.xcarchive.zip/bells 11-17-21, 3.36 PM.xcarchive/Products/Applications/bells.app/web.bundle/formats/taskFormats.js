const List = Quill.import("formats/list");

class TaskList extends List {
  constructor(el) {
    super(el);

    const isCheckList = el.hasAttribute("data-checked");
    el.addEventListener("touchstart", (e) => {
      if (!isCheckList) {
        return;
      }
      e.preventDefault();
    });
  }
}

Quill.register("formats/lists", TaskList);
