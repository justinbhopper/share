const Inline = Quill.import("blots/inline");
class UndoBlot extends Inline {
  constructor() {
      super(...arguments);
      this.undoBlot = true;
      this.ticks = 0;
  }
  tick() {
    this.ticks++;
  }
}
UndoBlot.blotName = "undo";
UndoBlot.tagName = "rh-undo";
UndoBlot.create = function create(data) {
    const node = document.createElement(UndoBlot.tagName);
    node.setAttribute("value", data.value);
    if (data.undo) {
        node.setAttribute("undo", data.undo);
    }
    return node;
}
UndoBlot.formats = function formats(domNode) {
    return domNode.tagName === UndoBlot.tagName ? "undo" : undefined;
}
UndoBlot.value = function value(node) {
  var _a, _b;
  return {
      undo: (_a = node.getAttribute("undo")) !== null && _a !== void 0 ? _a : undefined,
      value: (_b = node.getAttribute("value")) !== null && _b !== void 0 ? _b : "",
  };
}
function value(node) {
  var _a, _b;
  return {
      undo: (_a = node.getAttribute("undo")) !== null && _a !== void 0 ? _a : undefined,
      value: (_b = node.getAttribute("value")) !== null && _b !== void 0 ? _b : "",
  };
}
UndoBlot.isUndoBlot = function isUndoBlot(blot) {
  return blot && "undoBlot" in blot;
}

Quill.register(UndoBlot);
