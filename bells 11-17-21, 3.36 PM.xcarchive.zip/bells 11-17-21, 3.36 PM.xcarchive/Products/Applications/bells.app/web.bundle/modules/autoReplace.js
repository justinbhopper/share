const triggerKeys = [" ", ".", "?", "!", ",", ";"];
class AutoReplace {

  constructor(quill, options) {
    this.quill = quill;
    this.options = options;

    quill.on("text-change", this.handleTextChange.bind(this));

    this.replacements = [];
  }

  // Expecting, replacements will be provided from RN side as serialized data via WebView component
  setData(replacements) {
    this.replacements = replacements;
  }

  handleTextChange(delta, oldDelta, source) {
    try {

      const maybeRange = this.quill.getSelection();
      const ops = delta.ops;

      if (source !== "user" || !ops || ops.length === 0 || !maybeRange || maybeRange.length !== 0) {
        return;
      }

      const range = maybeRange;

      // Check last insert
      let lastOpIndex = ops.length - 1;
      let lastOp = ops[lastOpIndex];

      while (!lastOp.insert && lastOpIndex > 0) {
        lastOpIndex--;
        lastOp = ops[lastOpIndex];
      }

      // Only auto-correct if something was inserted and a trigger character occurred
      if (!lastOp.insert || typeof lastOp.insert !== "string") {
        return;
      }

      const triggered = triggerKeys.some(key => lastOp.insert.includes(key));
      if (!triggered) {
        return;
      }

      const [beforeCursor, offset] = this.getTextBefore(range.index);

      if (beforeCursor === null || offset === null) {
        return;
      }

      this.replacements.some(replacement => {
        const before = replacement.caseSensitive ? beforeCursor : beforeCursor.toLocaleLowerCase();
        const replace = replacement.caseSensitive ? replacement.replace : replacement.replace.toLocaleLowerCase();

        let replaceStart = -1;
        if (before === (replace + " ")) {
          replaceStart = offset;
        } else {
          // To ensure replacement triggers only for the last matching word
          const mistakeIndex = before.lastIndexOf(" " + replace);
          const ensureAtLast = mistakeIndex === (before.length - (replace.length + 2));

          if (mistakeIndex !== -1 && ensureAtLast) {
            replaceStart = offset + mistakeIndex + 1;
          }
        }

        if (replaceStart === -1) {
          return false;
        }

        const undo = beforeCursor.slice((-1 * replace.length) - 1, -1);
        let newIndex;

        if (typeof replacement.with === "string") {
          // Replace with other text
          this.quill.insertText(replaceStart, replacement.with);
          this.quill.deleteText(replaceStart + replacement.with.length, replace.length, "api");
          const blot = {
            value: replacement.with,
            undo,
          };
          this.quill.formatText(replaceStart, replacement.with.length, "undo", blot, "api");
          newIndex = replaceStart + replacement.with.length + 1;
        } else {
          // Replace with embed
          this.quill.insertEmbed(replaceStart, replacement.with.type, replacement.with.value, "api");
          this.quill.deleteText(replaceStart + 1, replacement.replace.length, "api");
          const blot = {
            value: "",
            undo,
          };
          this.quill.formatText(replaceStart, 1, "undo", blot, "api");
          newIndex = replaceStart + 2;
        }

        setTimeout(() => {
          this.quill.setSelection(newIndex, "api");
        }, 0);

        return true;
      });
    } catch (error) {
      alert(JSON.stringify(error))
    }
  }

  getTextBefore(index) {
    const [leaf, leafIndex] = this.quill.getLeaf(index);

    if (!leaf) {
      return [null, null];
    }

    const offset = leaf.offset(this.quill.scroll);
    const beforeCursor = leaf.value().slice(0, leafIndex);

    return [beforeCursor, offset];
  }
}

Quill.register("modules/autoReplace", AutoReplace);
