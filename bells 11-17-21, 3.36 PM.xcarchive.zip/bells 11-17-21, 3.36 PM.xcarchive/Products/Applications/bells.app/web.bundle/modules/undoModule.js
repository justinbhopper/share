class UndoModule {
  constructor(quill, options) {
    this.quill = quill;
    this.options = options;

    quill.on("text-change", this.handleTextChange.bind(this));
  }

  handleTextChange(delta, oldDelta, source) {
    const range = this.quill.getSelection();
    const ops = delta.ops;

    if (source !== "user") {
      return;
    }

    if (range) {
      const leaf = this.quill.getLeaf(range.index)[0];

      leaf.parent
        .descendants(UndoBlot.isUndoBlot, range.index, range.length)
        .forEach(this.removeUndo);

      if (UndoBlot.isUndoBlot(leaf.parent)) {
        this.removeUndo(leaf.parent);
      }
    }

    // Only if something was inserted
    if (ops?.some(o => o.insert)) {
      // Increment visibility ticks
      const undoNodes = this.quill.root.querySelectorAll("rh-undo");
      undoNodes.forEach(undoNode => {
        const undoBlot = Quill.find(undoNode, true);
        if (UndoBlot.isUndoBlot(undoBlot)) {
          undoBlot.tick();

          if (undoBlot.ticks > 10) {
            this.removeUndo(undoBlot);
          }
        }
      });
    }
  }

  revert = (maybeBlot) => {
    let blot = maybeBlot;

    if (!maybeBlot) {
      const undo = this.getUndoBlotAt(this.quill.getSelection());

      if (!undo) {
        return;
      }

      blot = undo;
    }
    const undo = UndoBlot.value(blot.domNode).undo;
    const index = this.quill.getIndex(blot);
    this.quill.deleteText(index, blot.length(), "user");

    if (undo) {
      this.quill.insertText(index, undo, "user");
      this.quill.setSelection(index + undo.length + 1, 0, "user");
    }
  };

  getUndoBlotAt = (range) => {
    const leaf = this.quill.getLeaf(range.index)[0];

    if (UndoBlot.isUndoBlot(leaf.parent)) {
      return leaf.parent;
    }

    return leaf.parent.descendant(UndoBlot.isUndoBlot, range.index)[0];
  };

  removeUndo = (blot) => {
    // Remove using "api" to prevent firing onChange again
    this.quill.formatText(blot.offset(this.quill.scroll), blot.length(), { undo: false }, "api");
  };
}

Quill.register("modules/undo", UndoModule);
